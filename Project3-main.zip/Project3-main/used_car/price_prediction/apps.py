from django.apps import AppConfig


class PricePredictionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'price_prediction'
