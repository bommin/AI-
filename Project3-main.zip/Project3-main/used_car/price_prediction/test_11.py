import matplotlib as mpl

print ('설정파일 위치: ', mpl.matplotlib_fname())